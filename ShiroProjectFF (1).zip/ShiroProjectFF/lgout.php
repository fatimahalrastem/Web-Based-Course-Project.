
<?php
unset($_SESSION["username"]);

echo '<script>
                    window.location.href = "index2.php";
                    </script>';
    ?>