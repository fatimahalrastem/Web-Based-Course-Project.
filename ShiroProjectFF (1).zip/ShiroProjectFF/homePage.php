<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>SHIRO STUDIO</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@200;300;400;500;600&family=Noto+Kufi+Arabic:wght@300;400;500;600;700&family=Noto+Sans+Arabic:wght@200;300;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="shirostyle.css" rel="stylesheet" type="text/css">
 
<style>
    *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    } 
    body{
        font-family: 'IBM Plex Sans Arabic', sans-serif;
        font-family: 'Noto Kufi Arabic', sans-serif;
        font-family: 'Noto Sans Arabic', sans-serif;
    }
    .navbar{
        display: flex;
        align-items: center;
        padding: 20px;
         background: #000000;
    }
    nav{
        flex: 1;
        text-align: right;
    }
    nav ul{
        display: inline-block;
        list-style-type: none;
    }
    nav ul li{
        display: inline-block;
        margin-right: 20px;
    }
    a{
        text-decoration: none;
        color: #fff;
    }
    p{
        color: #000000;
    }
    .container{
        max-width: 1300px;
        margin: auto;
        padding-left: 25px;
        padding-right: 25px;
    }
    .row{
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        justify-content: space-around;
    }
    .col-2{
        flex-basis: 50%;
        min-width: 300px;
    }
    .col-2 img{
        max-width: 100%;
        padding: 50px 0;
    }
    .col-2 h1{
        font-size: 50px;
        line-height: 60px;
        margin: 25px 0;
    }
    .col-2 p{
        color: #fff;
    }
    .btn{
        display: inline-block;
        background: #000000;
        color: white;
        padding: 8px 30px;
        margin: 30px 0;
        border-radius: 30px;
        transition: background 0.5s;
    }
    span {
  content: "\2192";
    }
    .btn:hover{
        background: #808080;
    }
    .header{
        background: radial-gradient(#fff,#000000);
    }
    .header row{
       margin-top: 70px; 
    }
    .categories{
      margin: 70px 0;  
    }
    .col-3{
        flex-basis: 30%;
        min-width: 250px;
        margin-bottom: 30px;
    }
    .col-3 img{
        width: 100%;
    }
    .small-container{
        max-width: 1080px;
        margin: auto;
        padding-left: 25px;
        padding-right: 25px;
    }
    .col-4{
        flex-basis: 25%;
        padding: 10px;
        min-width: 200px;
        margin-bottom: 50px;
        transition: transform 0.5s;
    }
    .col-4 img{
        width: 100%;
    }
    .rating{
    text-align: right;
    }
    .rating .fa{
    color: gold;
    } 
    .title{
        text-align: center;
        margin: 0 auto 80px;
        position: relative;
        line-height: 60px;
        color: #555;
    }
    .title:after{
        content: '';
        background: #000000;
        width: 80px;
        height: 5px;
        border-radius: 5px;
        position: absolute;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
    }
    h4{
        color: #000000;
        font-weight: normal;
    }
    .col-4 p{
        font-size: 14px;
        text-align: right;
    }
    .col-4:hover{
        transform: translateY(-5px);
    }
    .col-4 h4{
        text-align: right;
    }
    .col-7{
        flex-basis: 25%;
        padding: 10px;
        min-width: 200px;
        margin-bottom: 50px;
        transition: transform 0.5s;  
    }
    .col-7 img{
       width: 100%; 
    }
    .col-7 p{
        font-size: 14px;
    }
    .col-7:hover{
        transform: translateY(-5px);
    }
    .col-7 h4{
        text-align: right;
    }
    .offer{
        background: radial-gradient(#fff,#000000);
        margin-top: 80px;
        padding: 30px; 
    }
    .col-2 .offer-img{
        padding: 50px;
    }
    small{
        color: #555;
        
    }
    
    /*---testimonial---*/
    .testimonial{
        padding-top: 100px;
    }
    .testimonial .col-3{
        text-align: center;
        padding: 40px 20px;
        box-shadow: 0 0 20px 0px rgba(0,0,0,0.1);
        cursor:pointer;
        transition: transform 0.5s;
    }
    .testimonial .col-3 img{
        width: 50px;
        margin-top: 20px;
        border-radius: 50%;
    }
    .testimonial .rating{
        text-align: center;
    }
    .testimonial .col-3:hover{
        transform: translateY(-10px);
    }
    .fa.fa-quote-left{
        font-size: 34px;
        color: #000000;
    }
    .col-3 p{
        font-size: 12px;
        margin: 12px 0;
        color: #777;
    }
    .testimonial .col-3 h3{
        font-weight: 600;
        color: #555;
        font-size: 16px;
    }
    
    /*---icons---*/
    .icons{
        margin: 100px auto;
    }
    .col-5{
        width: 160px;
    }
    .col-5 img{
        width: 100%;
        cursor: pointer;
    }
   
    /*---footer---*/
    .footer{
        background: #000000;
        color: #8a8a8a;
        font-size: 14px;
        padding: 60px 0 20px;
    }
    .footer p{
        color: #8a8a8a;
    }
    .footer h3{
        color: #fff;
        margin-bottom: 20px; 
    }
    .footer-col-1, footer-col-2, footer-col-3, footer-col-4{
        min-width: 250px;
        margin-bottom: 20px;
    }
    .footer-col-1{
        flex-basis: 30%;
    }
    .footer-col-2{
        flex: 1;
        text-align: center;
    }
    .footer-col-2 img{
        width: 180px;
        margin-bottom: 20px;
    }
    footer-col-3, .footer-col-4{
        flex-basis: 12%;
        text-align: center;
    }
    ul{
        list-style-type: none;
    }
    .footer hr{
        border: none;
        background: #b5b5b5;
        height: 1px;
        margin: 20px 0;
    }
    .copyright{
        text-align: center;
    }
</style>
</head>
<body>
<div class="header">
<div class="container">
<div class="navbar">
    <div class="logo">
        <img src="https://media.zid.store/cdn-cgi/image/h=175,q=85/https://media.zid.store/dddf4b16-a4fa-4b62-add8-3b090ade4cb1/f15d6435-3536-4475-a2ac-bdb20e61e259.jpg" width="125px">
    </div>
    <nav>
    <ul>
	<?php
	
	if (! empty($_SESSION["username"])) {
		echo '<li><a href="javascript:0">'.ucfirst($_SESSION["username"]).'</a></li>|<a href="logout.php">Logout</a></li><li>'; 
	} 
	
	?>	
    <li><a href="index2.php">حسابي</a></li> 
    <li> <a href = "#contact">للتواصل</a></li>
    <li><a href="story.html">قصتنا</a></li>
    <li><a href="index.php?page=products">المنتجات</a></li>
    <li><a href="index.php">الصفحة الرئيسية</a></li> 
    </ul>
    </nav>

    <div class="link-icons">
                    <a href="index.php?page=cart">
						<i class="fa fa-shopping-cart"></i>
					</a>
                </div>
    </div>
  
    <div class="row">
    <div class="col-2">
        <h1>SHIRO STUDIO</h1>
        <p>متجر سعودي متخصص بالشموع المصنوعة يدويًا بروائح مختلفة و المبتكرة </p>
        <a href="index.php?page=products" class="btn"> تصفح الان <span>&#8594;</span></a>
    </div>
    <div class="col-2">
        <img src="https://media.zid.store/thumbs/dddf4b16-a4fa-4b62-add8-3b090ade4cb1/4184ae98-9b9c-40f5-8f58-e3ef9525ccda-thumbnail-770x770-70.jpeg">
    </div>
    </div>
    </div>
    </div>
	



    
    <!-- أحدث المنتجات -->
    <div class="categories">
        <div class="small-container">
            <div class="row">
        <div class="col-3">
            <img src="https://media.zid.store/thumbs/dddf4b16-a4fa-4b62-add8-3b090ade4cb1/2886f608-a3c4-45a3-a094-99581cfa83da-thumbnail-770x770-70.jpg">
        </div>
        <div class="col-3">
            <img src="https://media.zid.store/thumbs/dddf4b16-a4fa-4b62-add8-3b090ade4cb1/b1b11f96-f577-4394-b60b-7a8cd589c6b7-thumbnail-770x770-70.jpg">
        </div>
        <div class="col-3">
            <img src="https://media.zid.store/thumbs/dddf4b16-a4fa-4b62-add8-3b090ade4cb1/bc3ea4b6-c190-47b9-ae91-8f9e85dfbd19-thumbnail-770x770-70.jpg">
        </div>
        </div>
        </div>
    </div>
    
    
    
    
        <!--  المنتجات -->    
    <div class="small-container">
        <h2 class="title">المنتجات</h2>
        <div class="row">
        <div class="col-7">
        <a href="index.php?page=products"><img src="https://media.zid.store/thumbs/dddf4b16-a4fa-4b62-add8-3b090ade4cb1/eec8df97-5eb6-4c0c-a089-e9ea19013346-thumbnail-770x770-70.jpeg"></a>
            <h4> 
الشموع</h4>
            </div>
            
             <div class="col-7">
            <a href="index.php?page=products"><img src="https://media.zid.store/thumbs/dddf4b16-a4fa-4b62-add8-3b090ade4cb1/3e5d647b-0c66-4b16-9a5f-d8e09b8e86e1-thumbnail-770x770-70.jpeg"></a>
            <h4> 
معطرات المنزل</h4>
            </div>
            
            <div class="col-7">
            <a href="index.php?page=products"><img src="https://media.zid.store/thumbs/dddf4b16-a4fa-4b62-add8-3b090ade4cb1/da135a0a-5d7d-4b6a-9e7b-d143d42e1884-thumbnail-770x770-70.jpg"></a>
            <h4> 
المنسوجات اليدوية</h4>
            </div>
            
            <div class="col-7">
            <a href="index.php?page=products"><img src="https://media.zid.store/thumbs/dddf4b16-a4fa-4b62-add8-3b090ade4cb1/74838c12-bad8-4f98-9545-1ceb4c9eb0ce-thumbnail-770x770-70.jpeg"></a>
            <h4> 
مباخر وبخور</h4>
            </div>
            
            <div class="col-7">
            <a href="index.php?page=products"><img src="https://media.zid.store/thumbs/dddf4b16-a4fa-4b62-add8-3b090ade4cb1/da135a0a-5d7d-4b6a-9e7b-d143d42e1884-thumbnail-770x770-70.jpg"></a>
            <h4> 
الاكسسوارات المنزلية</h4>
            </div>
            
            <div class="col-7">
            <a href="index.php?page=products"><img src="https://media.zid.store/thumbs/dddf4b16-a4fa-4b62-add8-3b090ade4cb1/e51fbb3d-ef69-4267-902b-6c2205bf81b3-thumbnail-770x770.png"></a>
            <h4> 
شيرو ستيكر</h4>
            </div>
            
            <div class="col-7">
            <a href="index.php?page=products"><img src="https://media.zid.store/thumbs/dddf4b16-a4fa-4b62-add8-3b090ade4cb1/873ac1a7-09d0-4c62-8a63-fcc4f84939e7-thumbnail-770x770-70.jpg"></a>
            <h4> 
أفكار الهدايا</h4>
            </div>
            </div>
    </div>


<?php
// Get the 4 most recently added products
$stmt = $pdo->prepare('SELECT * FROM products ORDER BY date_added DESC LIMIT 4');
$stmt->execute();
$recently_added_products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

    <!-- أحدث المنتجات -->    
    <div class="small-container">
        <h2 class="title">أحدث المنتجات</h2>
		
        <div class="row">
		 <?php foreach ($recently_added_products as $product): ?>
        <div class="col-4">
		 <a href="index.php?page=product&id=<?=$product['id']?>" class="product">
            <img src="<?=$product['img']?>">
            <h4><?=$product['name']?></h4>
            
            <div class="rating">
            <i class="fa fa-star" ></i>
            <i class="fa fa-star"></i>
            <i class="fa fa-star"></i>
            <i class="fa fa-star"></i>
            <i class="fa fa-star-half-o"></i>
            </div>
            <p><?=$product['price']?> رس</p>
             </a>
			 </div>
        <?php endforeach; ?>
		</div>	
		</div>
           
    <!--- offer --->
    <div class="offer">
    <div class="small-container">
        <div class="row">
            
            <div class="col-2">
            <h1>! جربها بنفسك</h1>
                <small>تمتع بتجربة صنع شمعتك الخاصة برائحتك المفضلة</small>
                <br>
                <a href="" class="btn">أحصل عليها الان <span>&#8594;</span></a>
            </div>
            
             <div class="col-2">
            <img src="https://media.zid.store/thumbs/dddf4b16-a4fa-4b62-add8-3b090ade4cb1/057473b3-c4db-4f59-ad12-d6d76692bf13-thumbnail-770x770-70.jpg" class="offer-img">
            </div>
        </div>
    </div>
</div>
    
    <!---testimonial--->
    <div class="testimonial">
    <div class="small-container">
        <div class="row">
        <div class="col-3">
            <i class="fa fa-quote-left"></i>
            <p>شموع رائعة جدا خصوصًا رائحة الياسمين كان جميلة جدًا و أيضًا طلبت سجاد مرسوم جودته وحجمة ممتازين</p>
            <div class="rating">
            <i class="fa fa-star" ></i>
            <i class="fa fa-star"></i>
            <i class="fa fa-star"></i>
            <i class="fa fa-star"></i>
            <i class="fa fa-star"></i>
            </div>
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAABUFBMVEUzcYD///9gLw/0s4IzMzv57+jio3kxc4NiKwDTPT0ycIAsbX0ma3sxMzzhoXbouJj/9u8dZ3iqwMc/eYfy9vfjRERWJAAoKTPZ5ObI1tqxxssNY3RhLQmSsLft8vOgucAjJC+Gpq9xmaNcjJhMgo/T3+J6nqdOTUb8toJRhJFFW10qKzRcNRvYm21VIgBJd38cHirg6+dTRjs6Z3BLU1BAYWdzQSFmNBTrq3vu6+MWGSZLWVtmSjVmQSlWQDJbNx+aZUG8glpIEQChlIHAoIFpgYDulXHkgGPaW07vonjgblnqsILPnXqEhn2ylXvZoHqddl9AOz+hm5pOMSVtV07MxMCMh4hHRkx7d3nk2dLW39aWtLGxuLlaZWc+P0WJVjSvd1Gak4PMpYFrcGhif4DRKzWLcFs6UVmTl5U/IhjKkWxIMSq5rqd9dHJYVlrQyMMganJ+AAATAUlEQVR4nM2d+XfTxhbHx7EduZacZ0WuYjsieMmKs0GaxA4thFKgJVAKFLKQpeuDBzT8/7+9kWTLkmbRaO4o6ffAySEkkj6+y9xZhXKZq1ZvNKdvtjvdlXnLshD+O7/S7bRvTjcb9Vr2t0cZXhuj3VjsWqZpGoah66iM3D/+F13H38P/Y3UXb2QLmhVhvdnuWobpgvGFUU3D6rab9YyeJAvC+nTHg0tgi3C6mJ3pLChVE9YabWs2FVwYc9ZqN1R7rFLCuWZHNw0pupEMU+8051Q+lDrCWrODTDnjxUxpok5TnSVVEdbb6QIvAdIw26piUglhbXrFNMrK+FyVDXNlWokhFRDW20ih+cbSDaTCkGDCeseA5RaeDKMDZgQSLnRndbXuGVVZn+0uXCPhQkdJ8uRLNzsgRgAh9s/s+TxGkK9KE9baV2C/gNFsS+dVWcJpPbv8QpOhT18p4cK8eaV8rsx5uXCUImxfUQBGpRvtKyJsXLGDjmXojSsgrC1evYOOZS6mzjhpCRvWdRnQl2GlNWNKwhvXaUBf5o0MCedWrteAvoyVVD3kNIQNdB0plJSO0nhqCsKbZpY1dhqVzZtZEHb+NYAuYkc54dy8ihAs+1JwJWNeNBgFCesWKATLmie04Qv5/wSR6pZgf0OMsJE4dM2Ri7Z9d+nb71ZXd32trn737dLdbe9/5BEFCxwhwuas7GNg46FbSxOlUslxnImx8L/w9yaWbiGAKWebqginpZt5jHcPw02whDHvYUjZy5siPSoBwpuSgGUNLa1y8EaQq0tI1o4irUYyoWyhhvmcUgKer5KzJGtHgRIukVAa8JYgn894KzPEJEJJF9XQHXE+j/GOpBkTHTWBUDLJaFsT6QAx4sSWJGJCuuETNiUBt52kBEPKcbYlEfmNBpewIdcOarfSGnBoRslgnOU2/TzCulwho23LAWJESSvqvAKOQzgnV4viGJSXXCzqFqcM5xDOS9ai99PH4EjOfblb6vMyhB257pKWspmIqnRHzk8Ndn+RSSjbEEoH4RBRNqEym0UWYUOyR6+tggAnJlblCMsmK6EyCOeQJOASzITYiEuSiIiRbRiEK7I9XvksM5IjeWd9JQ3hDclBGbgJ5Y2IDHoRTiVsSHd5wXyuZG9OD0UaYc2SvIX2DdyE2IjfyHb6Ldq0DY1wUXrgEJpIfa3K3t5YFCOU9lFtS4UJsREl+1F0P6UQSg8cakvwTOrKkc01OKGKELalfVRTA4gRpQkpE+EE4YI8ILBgG0u2dHMRieUMBKFsj0K0MdwRIQS4KdHLiBPKj/4iTajbtC/wM859+dF+YtgmRlgDzE8I9XztqXWRH9uSfwy9xiWUTzNiYWjvL18IAAICkUg2UcI6YCGCUBjaU/k1ASMCAhH7aZ1D2IFMot1LDkN7P5/PX9iJP+fcg0y7ddiE8i2F2z8TKNl2MGC+v5v8g6uS/VNP0RYjQggxIRIo2db7LqGIn5YAqSZmxDDhAmQ5kECicdbyvtYS/RmSanAkLjAIuxATaneTCHdHgBgxkfAuhFDv0gnr0nPZHmFCKrV3pvJjTe3y0w0omSI0W6cSgqIwKZV6WTQsfkYFJdNoJI4J67BdL9yazd59kI/rwQSHEVK3IXfHTZ1CCChnPEKORdb3+wQgbjUueDkVRBgubALCGuiKmJAZhus7axQ+Vx/Z0ViCESJUIwinYSYsIwYhzUFDrspiLEGafCxjmiCUHgMeit7g27u/cfhc/UZnBDX5KDw+PCKE1NyuqA0+th8tAGPhSLUjrMlHofp7RAjMM5SZbdve4flnxFd37Dik7Ix3oCDXDAlr0MWjcUJ7d39tWRAwn19e248ZEkxYNmsRwiZ09WiE0F7fEXDPuLPurNsKCZHRjBDC6pkIob3u7LOaB77W9p11RxnhqK7xCeeAVxsX3q53SuGNIIeVDqz09jUXIpRcGUQS2qLJha0HtiLC4UoipMZJR9NO62DAfN6r5eQnoAIN3dQjhIwhjrR1z11KaisgtN1Fp/eALb6HWAsI5WdEx9K0rdeOEhvauGexBVkBPpI/E4VUNPee9N8PLuz1tI0Eqf66fXHwu4rdOX6j7xHKzvlGLvdwOd/fXYckUl9r67v9/PJDFR+6NSKEDV/4Km+4FcyD7xUQfu/m4+UNBftOvMEMBO84edJ/dwn7zK6guKZ2XE9ffqjAT70uFFLSVuCL/SBehQrpBxUfe2dICL8UJvxDLWD+DyVbHX3CuoprKSc8ULFb1R2QQgr6Fd61lNtQCWHTI1TSGv47vdRtERFwMD+41r8x03jD+0h+jVdEboOvUss/K8k0Vg0TQsegfOnPFRMqqdvc8SikpOzGhfefigkfqSFsYELZtaQxOYoJVVRt3ppTlFtU8WFpd2x4ryKsAzVb//VFTKgilWrbJfujUkI1JY2bTJGSrpN2z7GThu9TSU3vCbkdKFRT0b93hxIvlBKqSTQ41dSQisbC22SxqzIQD9QkGre5QAoaC3802IZ3DcdSFIZuc4EU1N3+BDcxUw/Q8nNVp6gYTQTv4I8m1hx1bnqgAs6TMY1uwgmHqzDsfVWNvjoTIuMmaoMvFsz+rj9Qgri8rKRf4UtvI/is03ipkH3xANzuL//w83OFZzXpHdQFXyS8kMb+HhqMBypP68XqohVowxNdogAtbZSMIoZUXkHzwEvE9zrtAAlVNfUjzSNoWRpf7QVs+JU19SNZyAJ+ZvF1NLCGX2E74atsQW1IrjIB1acH0A+cELjrRO7mgkx0q2wJA0FtSC4rBXSjlv9SfiYcPA7JFfqAOUQlA90RweOQthXoQrZ4U9bvDckCtof0BXuyRlTeVCC3PYTVNPSjaOiR+PTrr79++rj/2Pt6VSbENQ2sLqXvQaCNu/30dUQ/UgCzSKSYD7hCn74/nSzdYoBYJKLqgs0V7lvA+ocMQqL+xoBf+Qq+xq24/HsWJsT9Q1gfn7WPZH0q+vhP/v4qrr+fRH/kRSYn+OI+PmychrlBPe6nTwjCGGBefWPvypgGjrUxz4kg/fTHCN+PP12Fj3pjbbDxUvbBZWQ+/enpV76v/v3V0xhfRnkUeeOlsDFv3p68qThivv/4ydOnT588Jnofyy+A2yuYMuvQeQvOvsoU3aiDrADdeQvg3BNvi/qOKOLBRmYHhVvQ+UPu7l9bcMzm4K/MAL35Q9gcMHfboS3WVcygHB3JmwOGzePzjxWydw6u00WH8/jA5iJhg/NGImGWgP5aDFhzwdyV52tVe8ZPN/1nmZ5l762nAa6J4gaic0/7eYqH2J9Ss/aJJW9NFHAxBvc41tKS9nxqcpLF2J+cnFI9QBqRv64NvDaRR3hLe4QJJyepgO5/TD3K0kuHaxOB89w8Ny1taxuTvuJ27A+/n0W3N9BwfSlwjTDPTTGh9mKSwjjim3yhYOcIW8M1wsB13ryyprSFjGeTY/X7/Tz+G/rOs2zfXKNmrT7nvAiX8OdJnjJNpcFafehyjC1mIHqEUxzAbBuLYL8FdM+MdoeFWNrSrpMw2DMDXrzH7CTiTKM/5BIqntSOylK2d41pREx4jTYM7V0Dr21jGdEjvLZME9p/CN5DykqnpbtapLUglWVrEdpDCt7bxWoTS99oxgsuYTbjwJ7C+4Dhe7kZhY1zJ6jaWMquaovs5VawH59end4fVt5MZVl5h/fjK9iCyEg2BrexcJuLrNw0eqaCgv1r9AGb0jY/DHEgqqChKXYuBvhsE0R/64Pz3wRA3AX2XsGm5HVzYcXPNlGwRY96ErRzkUQ4+cv53VvbGxsWgr5rLqr4+TQq9ndR/XQnyUsnf+0VCoVer3B49/32BrJUURJnDIHPiUJlw6D4qfMxifBlpRCo9/Lw/V9bGxr8ld/kOVHALpRuzs7fOPlMHsBm7ycAfpwpRIVN+qHRtoALaSlnfQHOa9NNrdMcVKvVV/8jjbiTFIZxQsx4hK91ctpFEFOS57XJ5hrdtBYbg2oRq3rUI4s3O8FNvTCMy7/coNmR9VfamXty5yYapmu9oq9qofKSMKKT4KYvKYCbx6MrDppdU+K56OcmStQ1hvYuwMM63ixU7pO5hh+GLQph603oqifvjNSM9LMv0w5mlM35ZjH0JMXqG/dpCSPaD1KGISZ8Fbnu4N18SkbG+aXphvdNK8qHn+QVftrKa3K9KQewTw1DnGqiVy42rTRFF+sM2jTnCOtR//Sf48x7WsJNdzm1d58GWKgcFuPXHrxL0XowzxEWjsSy2SH4sM7dtps0Ii+bUsMQX+SYuHh10BU1APssaNHzvHWrSeErHg9DigjE31KGIU6mbyjXrzY1MQtwzvMWM6KxckIDrH7e9D//1+LtBT0M46kmuMOJ0KuzeWeyC9XfRodyc/f+b317kG0ip6wJF6WcVDPSoCuAyD1XX6CwMTr0mxeLl0N7VMRTzUe6CQuVS8Y9qslv9OO/GyF5XFFnWBB/vsHjfYoZcXctZRgWCjNkqhkqsUlLeL9F0jtKytaAdesvm6PHi7spm5ARhoxU43+QCROOSe8oSXrPjNlg+Wj1VZD4K7H622ESMsKQlWq8+/BHPpPfM8NvMfQu68a4YxF4XDybMhtEom8YiJVq3Btx/VTgXUHcZGM2WPctVg/HeSIWiPYvacOwUDhkEhZ5sywi73vivbOLE4XF4t748WKBuPpr2jAsFPbYNxpwNjIJvbOLMxOlM1uKYvHNZuj5ol76usIgZPLxUg1uMZg2EHzvGvvdecY7dnS8CleY0UTzqUUPREZR6omdaorVd8znE3x3HnsdmHnC/mDPwh4XTaaFGXogcsKQl2qKJywnE37/IdNPOWFYDT9etLm4X6n82p8ixSpKfXFSzYBhAfF3WLLeQ8ppK4KOBWlDBzd6vf/QxOHDRuR8mvT2Is17SBnjw7wwfBOJqagJcVQdV0kdc5wU/8oXNiE1ENO9S5b+PmCjyb7p28jjRqLQfdzP5GdT/cxJNPRfGYk2U5b2fcDUdzobnERzGYqpcP/J+eQWZr1/KIT/cG04w0s1JGHqdzrT3std1tmhMTgPPVxoIMN57VWe5MAL1iGrKPXUY3Wg3LvpxMef/r3clHerly1Oogl73HjQ1FkdUlB6Q8e8TIp1zuxAFatEVSPzbnWyl8GpaGIx5QSAo++QUTUa9GBqk5Nq4lUN2aMQIpyzotfhpdJwogmcdOiins8RgRjqi9CVoqrRLUaWSSDM1aOEJjuVFsOJJsikn8aBRgnES24Y4g/lLSeZRpOEXudQ8Ahzjcg4P6dmK4Yz6euhh0a6t3vxqDpOcFJuqonWbbOsNJpMGF1JZLJT6Zdx18nvHDrYgBEbxQMxoTX0ENmEg8hzNbkMfMLwsE15nnnD0ONWXvp8hZgPxgMxViLQtMdONcX5cTIlBmbSEYaaRV4qfTvyUgzoOKsEn6sYIXOIJhCnqgklU3ZDKEiYuzFCNNrsG45GMNxq5vXLCu3hY4F4vEf5mahm2KmmGgy1mPRyOw1hgMipSoMRjJcuHt04UYsIhCHOv8mVaTKgAOHIUTmpNBgqZeEV4oEoEIbY7Imd4EQXFSMcphuDmUpFDILtG/mV88Qw5FY1A0MkyQgT5pqz3HG26lFCiempFw7EpKLUEyfVeONts/xmIg1hrqHrepf5gVb5vQTK8yYWpZ44qabYxU/EbehTEubqlrnIvN2xwNNGAzGhbzj6jUt2Ml00LV6plp4Ql+HsuvuLSBhGS9OkotTXOdOE1Xe8YluKMFdjptLoUClbm+NA5A/RBJphp5oT2sAhjDCXu80iFEo04UAUC0Neqrkt/tgpCHO3GdlUzOVCgTiu8vhipZpBCsBUhLk5qqcKZf6CW9Kl/kzOqIQnoiGYnjBXo3nqGzGXC5WmAkWp/5mc07zmtnAIShDSPFU00YzDSqwGcrVJjkal8lAZQtKMoolmHIhCRWnkM5E2oAwhaUahisbTzJCQtqaU/guxVJPagHKEsaZxIBhUhcDpEodoAvXOIoDijSCQMGLGqnCiGTmdeBhiAQ0oTYijccQonmhGgSgehuGRgUH6CAQRjjNOdPKXL780FeuK+ApSjSwfgBC7qheO1eTHHMsrNMW6IsNf8Ae+T+QcFEroMx6nCCrPJKJFqSevAwXhAxJixtufxVOpH4iiRamvmSqMD0yYyy2ctcQThxeIgkWpx9c6A/IpIMSMbyvCnrp3XBV361blLbFK7VoIcZ/jw/mecB9RMAx7e+cfUvUhWFJCiNU4arUEIHEgirSGvVbrSGycKVmqCHEDeXrWE4CsLiWFYa81c3Yq3fwRUkeIVceQm3zIzS98J+1tYjzBUTQxKSXMuZY86u1xTFnhZNJea693pNB6vlQTulo4PSu0WjN0TMb2Axx5hbNTBamTUBaErhqnR5eVTRZmBG6mtVm5PMqEzlVWhK7m6qcfjt5X9jZbFItisFZrc6/y/ujDaV1Js8BQloRD1Rqnp6cf/jy7e3l4eF4onJ8fHl5enj36gL/bUB10FP0fTSbUw7oqcyIAAAAASUVORK5CYII=">
            <h3>سارة أحمد</h3>
            </div>
            
            <div class="col-3">
            <i class="fa fa-quote-left"></i>
            <p>شموع رائعة جدا خصوصًا رائحة الياسمين كان جميلة جدًا و أيضًا طلبت سجاد مرسوم جودته وحجمة ممتازين</p>
            <div class="rating">
            <i class="fa fa-star" ></i>
            <i class="fa fa-star"></i>
            <i class="fa fa-star"></i>
            <i class="fa fa-star"></i>
            <i class="fa fa-star"></i>
            </div>
            <img src="https://cdn-icons-png.flaticon.com/128/3135/3135715.png">
            <h3>علي خالد</h3>
            </div>
            
            <div class="col-3">
            <i class="fa fa-quote-left"></i>
            <p>شموع رائعة جدا خصوصًا رائحة الياسمين كان جميلة جدًا و أيضًا طلبت سجاد مرسوم جودته وحجمة ممتازين</p>
            <div class="rating">
            <i class="fa fa-star" ></i>
            <i class="fa fa-star"></i>
            <i class="fa fa-star"></i>
            <i class="fa fa-star"></i>
            <i class="fa fa-star-half-o"></i>
            </div>
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSIltE7CNXgJ95jKIkczNnzcVEbiox9t0c-sg&usqp=CAU">
            <h3>خالد عبدالعزيز</h3>
            </div>
        </div>
        </div>
    </div>
    
    <!---icons--->
    <div class="icons">
        <div class="small-container">
        <div class="row">
        
            <div class="col-5">
            <a href=""><img src="https://media.zid.store/static/apple_pay.svg"></a>
            </div>
                    
            <div class="col-5">
            <a href=""><img src="https://media.zid.store/cdn-cgi/image/h=80,q=85/https://media.zid.store/static/mada-circle.png"></a>
            </div>
                    
            <div class="col-5">
            <a href=""><img src="https://media.zid.store/cdn-cgi/image/h=80,q=85/https://media.zid.store/static/visa-circle.png"></a>
            </div>
                    
            <div class="col-5">
            <a href=""><img src="https://media.zid.store/cdn-cgi/image/h=80,q=85/https://media.zid.store/static/mastercard-circle.png"></a>
            </div>
            
            <div class="col-5">
            <a href=""><img src="https://media.zid.store/static/tamara2.svg"></a>
            </div>
            
            </div>
        </div>
    </div>
    
       <!---footer--->
    <div class="footer">
    <div class="container">
        <div class="row">

            <div class="footer-col-4">
            <h3 id="contact">للتواصل</h3>
            <ul>
            <li>ِ<a href="mailto:Shirostudio21@gmail.com"><i style="font-size:24px" class="fa">&#xf003;</i>  Email</a></li>
            <li><a href="https://api.whatsapp.com/send/?phone=966591110744&text&type=phone_number&app_absent=0"><i style="font-size:24px" class="fa">&#xf232;</i>  Whatsapp </a></li>
            </ul>
            </div>
            
            <div class="footer-col-2">
            <img src="https://media.zid.store/cdn-cgi/image/h=175,q=85/https://media.zid.store/dddf4b16-a4fa-4b62-add8-3b090ade4cb1/f15d6435-3536-4475-a2ac-bdb20e61e259.jpg">
            <p>هدفنا هو حصولكم على أجود المنتجات المصنوعة خصيصًا لكم</p>
            </div>
            
            <div class="footer-col-3">
            <h3>حساباتنا</h3>
                <ul>
                <li><a href="https://www.tiktok.com/@shiro_studio">TikTok</a> </li>
                <li><a href="https://www.instagram.com/shirostudio1/"><i style="font-size:24px" class="fa">&#xf16d;</i>  Instagram </a></li>
                <li><a href="https://www.snapchat.com/add/shiro_studio21"><i style="font-size:24px" class="fa">&#xf2ab;</i>     Snapchat</a> </li>
                </ul>
            </div>
        </div>
        
           <hr>
            <p class="copyright">Copyright 2023 - Group 6</p>
        </div>
    </div>
    
</body>  
</html>