
<?php
    include('connection.php');
    if (isset($_POST['submit'])) {
        $username = $_POST['user'];
        $password = $_POST['pass'];
        
        $sql = "select * from signin where username = '$username' and password = '$password'";
        $result = mysqli_query($conn, $sql);  
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
        $count = mysqli_num_rows($result);  
        if($count == 1){
            $_SESSION["username"] = $username;
            echo '<script>
                        window.location.href = "HomePageUser.php";
                    </script>';
        } else{
            $sql = "SELECT `Username`, `Password` FROM `adminlogin` WHERE `Username` = '$username' and `Password` = '$password'";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
            $count = mysqli_num_rows($result);
            if($count == 1){
                echo '<script>
                        window.location.href = "adminPage.php";
                    </script>';
            } else{
                echo '<script>
                        window.location.href = "index2.php";
                        alert("Login failed. Invalid username or password !!")
                    </script>';
            }
        }else {
            echo '<script>
                        window.location.href = "index2.php";
                        alert("Login failed. Invalid username or password !!")
                    </script>';

        }
        }
    }

    ?>