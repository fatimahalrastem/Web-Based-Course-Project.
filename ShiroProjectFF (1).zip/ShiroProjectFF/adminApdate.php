<?php

@include 'connection.php';

$id = $_GET['edit'];

if(isset($_POST['update_product'])){

   $product_name = $_POST['product_name'];
   $product_price = $_POST['product_price'];
   $product_des = $_POST['product_des'];
   $product_quan = $_POST['product_quan'];
   $product_image = $_FILES['product_image']['name'];
   $product_image_tmp_name = $_FILES['product_image']['tmp_name'];
   $product_image_folder = 'uploaded_img/'.$product_image;

   if(empty($product_name) || empty($product_price) || empty($product_image)|| empty($product_des) || empty($product_quan)){
      $message[] = 'لم يتم تعبئة جميع الحقول';    
   }else{
       // here
      $update_data = "UPDATE products SET  `name`='$product_name', `price`='$product_price', `img`='$product_image' , `quantity`='$product_quan', `desc`='$product_des' WHERE id = '$id'";

       $conn->init();
       // and here
       if ($conn->query($update_data) === true) {
         move_uploaded_file($product_image_tmp_name, $product_image_folder);
           echo '<script>
		   window.location.href ="adminPage.php";
		   </script>';
      }else{
         $message[] = 'لم يتم تعبئة جميع الحقول';
      }

   }
};

?>

<!DOCTYPE html>
<html lang="en">

<head>
<!--css-->
<style>
 *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    } 
    body{
        font-family: 'IBM Plex Sans Arabic', sans-serif;
        font-family: 'Noto Kufi Arabic', sans-serif;
        font-family: 'Noto Sans Arabic', sans-serif;
    }
    .navbar{
        display: flex;
        align-items: center;
        padding: 20px;
         background: #000000;
    }
    nav{
        flex: 1;
        text-align: right;
    }
    nav ul{
        display: inline-block;
        list-style-type: none;
    }
    nav ul li{
        display: inline-block;
        margin-right: 20px;
    }
    a{
        text-decoration: none;
        color: #fff;
    }
    p{
        color: #000000;
    }
    .container{
        max-width: 1500px;
        margin: auto;
        padding-left: 25px;
        padding-right: 25px;
    }
    .row{
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        justify-content: space-around;
    }
    .col-2{
        flex-basis: 50%;
        min-width: 300px;
    }
    .col-2 img{
        max-width: 100%;
        padding: 50px 0;
    }
    .col-2 h1{
        font-size: 50px;
        line-height: 60px;
        margin: 25px 0;
    }
    .col-2 p{
        color: #000;
    }
    .btn{
        display: inline-block;
        background: #000000;
        color: white;
        padding: 8px 30px;
        margin: 30px 0;
        border-radius: 30px;
        transition: background 0.5s;
    }
    span {
  content: "\2192";
    }
    .btn:hover{
        background: #808080;
    }
    .header{
        background: radial-gradient(#fff,#000000);
    }
    .header row{
       margin-top: 70px; 
    }
    .categories{
      margin: 70px 0;  
    }
    .col-3{
        flex-basis: 30%;
        min-width: 250px;
        margin-bottom: 30px;
    }
    .col-3 img{
        width: 100%;
    }
    .small-container{
        max-width: 1080px;
        margin: auto;
        padding-left: 25px;
        padding-right: 25px;
    }
    .col-4{
        flex-basis: 25%;
        padding: 10px;
        min-width: 200px;
        margin-bottom: 50px;
        transition: transform 0.5s;
    }
    .col-4 img{
        width: 100%;
    }
    .rating{
    text-align: right;
    }
    .rating .fa{
    color: gold;
    } 
    .title{
        text-align: center;
        margin: 0 auto 80px;
        line-height: 60px;
        color: #555;
    }
    .title::after{
        content: '';
        background: #000000;
        width: 80px;
        height: 5px;
        border-radius: 5px;
        position: absolute;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
    }
    h4{
        color: #000000;
        font-weight: normal;
    }
    .col-4 p{
        font-size: 14px;
        text-align: right;
    }
    .col-4:hover{
        transform: translateY(-5px);
    }
    .col-4 h4{
        text-align: right;
    }
    .col-7{
        flex-basis: 25%;
        padding: 10px;
        min-width: 200px;
        margin-bottom: 50px;
        transition: transform 0.5s;  
    }
    .col-7 img{
       width: 100%; 
    }
    .col-7 p{
        font-size: 14px;
    }
    .col-7:hover{
        transform: translateY(-5px);
    }
    .col-7 h4{
        text-align: right;
    }
    .offer{
        background: radial-gradient(#fff,#000000);
        margin-top: 80px;
        padding: 30px; 
    }
    .col-2 .offer-img{
        padding: 50px;
    }
    small{
        color: #555;
        
    }
	
	   /*---testimonial---*/
    .testimonial{
        padding-top: 100px;
    }
    .testimonial .col-3{
        text-align: center;
        padding: 40px 20px;
        box-shadow: 0 0 20px 0px rgba(0,0,0,0.1);
        cursor:pointer;
        transition: transform 0.5s;
    }
    .testimonial .col-3 img{
        width: 50px;
        margin-top: 20px;
        border-radius: 50%;
    }
    .testimonial .rating{
        text-align: center;
    }
    .testimonial .col-3:hover{
        transform: translateY(-10px);
    }
    .fa.fa-quote-left{
        font-size: 34px;
        color: #000000;
    }
    .col-3 p{
        font-size: 12px;
        margin: 12px 0;
        color: #777;
    }
    .testimonial .col-3 h3{
        font-weight: 600;
        color: #555;
        font-size: 16px;
    }
    
    /*---icons---*/
    .icons{
        margin: 100px auto;
    }
    .col-5{
        width: 160px;
    }
    .col-5 img{
        width: 100%;
        cursor: pointer;
    }
   /*---footer---*/
    .footer{
        background: #000000;
        color: #8a8a8a;
        font-size: 14px;
        padding: 60px 0 20px;
    }
    .footer p{
        color: #8a8a8a;
    }
    .footer h3{
        color: #fff;
        margin-bottom: 20px; 
    }
    .footer-col-1, footer-col-2, footer-col-3, footer-col-4{
        min-width: 250px;
        margin-bottom: 20px;
    }
    .footer-col-1{
        flex-basis: 30%;
    }
    .footer-col-2{
        flex: 1;
        text-align: center;
    }
    .footer-col-2 img{
        width: 180px;
        margin-bottom: 20px;
    }
    footer-col-3, .footer-col-4{
        flex-basis: 12%;
        text-align: center;
    }
    ul{
        list-style-type: none;
    }
    .footer hr{
        border: none;
        background: #b5b5b5;
        height: 1px;
        margin: 20px 0;
    }
    .copyright{
        text-align: center;
    }
     /*----all products page------*/

.row-2{
justify-content: space-between;
margin:100px auto 50px;
}

select{
border: 1.5px solid #656565;
padding: 5px;
}
.page-btn{
margin:0 auto 80px;
}
.page-btn span{
display:inline-block;
border: 1px solid #000;
margin-left:10px;
width:40px;
height:40px;
text-align:center;
line-height:40px;
cursor:pointer;
}
.page-btn span:hover{
background: #000;
color:white;
}

/*----single product detail------*/

.single-product{
margin-top: 80px;

}
.single-product .col-2 img{
padding:0;
}
.single-product .col-2{
padding:20px;
}
.single-product h4{
margin:20px 0;
font-size:22px;
font-weight:bold;
}
.single-product select{
display:block;
padding:10px;
margin-top:20px;
}
.single-product input{
width:50px;
height:40px;
padding-left:10px;
font-size:20px;
margin-right:10px;
border:1px solid #000;
}
.single-product .fa{
color:#000;
margin-left:10px;
}
.small-img-row{

display:flex;
justify-content:space-between;
}
.small-img-col{
flex-basis:24%;
cursor:pointer;
}
	@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600&display=swap');

:root{
   --darkgray:#696969;
   --black:#000000;
   --white:#fff;
   --bg-color:#DCDCDC;
   --box-shadow:0 .5rem 1rem rgba(0,0,0,.1);
   --border:.1rem solid var(--black);
}

*{
   font-family: 'Poppins', sans-serif;
   margin:0; padding:0;
   box-sizing: border-box;
   outline: none; border:none;
   text-decoration: none;
   text-transform: capitalize;
}

html{
   font-size: 62.5%;
   overflow-x: hidden;
}
.btn{
   display: block;
   width: 100%;
   cursor: pointer;
   border-radius: .5rem;
   margin-top: 1rem;
   font-size: 1.7rem;
   padding:1rem 3rem;
   background: var(--black);
   color:var(--white);
   text-align:center;
}

.btn:hover{
   background: var(--darkgray);
}
.message{
   display: block;
   background: var(--bg-color);
   padding:1.5rem 1rem;
   font-size: 2rem;
   color:var(--black);
   margin-bottom: 2rem;
   text-align: center;
}


.container{
   max-width: 1200px;
   padding:2rem;
   margin:0 auto; 
}

.admin-product-form-container.centered{
   display: flex;
   align-items: center;
   justify-content: center;
   min-height: 100vh;
   
}

.admin-product-form-container form{
   max-width: 50rem;
   margin:0 auto;
   padding:2rem;
   border-radius: .5rem;
   background: var(--bg-color);
}

.admin-product-form-container form h3{
   text-transform: uppercase;
   color:var(--darkgray);
   margin-bottom: 1rem;
   text-align: center;
   font-size: 2.5rem;
}
.admin-product-form-container form .box{
   width: 100%;
   border-radius: .5rem;
   padding:1.2rem 1.5rem;
   font-size: 1.7rem;
   margin:1rem 0;
   background: var(--white);
   text-transform: none;
}

.product-display{
   margin:2rem 0;
}

.product-display .product-display-table{
   width: 100%;
   text-align: center;
}

.product-display .product-display-table th{
   padding:1rem;
   font-size: 2rem;
}

.product-display .product-display-table td{
   padding:1rem;
   font-size: 2rem;
   border-bottom: var(--border);
}
.product-display .product-display-table thead{
   background: var(--bg-color);
}

.product-display .product-display-table .btn:first-child{
   margin-top: 0;
}

.product-display .product-display-table .btn:last-child{
   background: var(--black); 
}

.product-display .product-display-table .btn:last-child:hover{
   background: var(--black);
}
@media (max-width:991px){

   html{
      font-size: 55%;
   }

}

@media (max-width:768px){

   .product-display{
      overflow-y:scroll;
   }

   .product-display .product-display-table{
      width: 80rem;
   }

}
@media (max-width:450px){

   html{
      font-size: 50%;
   }


</style>

   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<body>
<div class="navbar">
    <div class="logo">
        <img src="https://media.zid.store/cdn-cgi/image/h=175,q=85/https://media.zid.store/dddf4b16-a4fa-4b62-add8-3b090ade4cb1/f15d6435-3536-4475-a2ac-bdb20e61e259.jpg" width="125px">
    </div>
    <nav>
    <ul>
    <li><a href="index2.php">حسابي</a></li> 
    <li> <a href = "#contact">للتواصل</a></li>
    <li><a href="story.html">قصتنا</a></li>
    <li><a href="index.php?page=products">المنتجات</a></li>
    <li><a href="index.php">الصفحة الرئيسية</a></li> 
    </ul>
    </nav>

    <div class="link-icons">
                    <a href="index.php?page=cart">
						<i class="fa fa-shopping-cart"></i>
					</a>
                </div>
    </div>

<?php
   if(isset($message)){
      foreach($message as $message){
         echo '<span class="message">'.$message.'</span>';
      }
   }
?>

<div class="container">


<div class="admin-product-form-container centered">

   <?php
      
      $select = mysqli_query($conn, "SELECT * FROM products WHERE id = '$id'");
      while($row = mysqli_fetch_assoc($select)){

   ?>
   
   <form action="" method="post" enctype="multipart/form-data">
      <h3 class="title">update the product</h3>
      <input type="text" class="box" name="product_name" value="<?php echo $row['name']; ?>" placeholder="ادخل اسم المنتج">
      <input type="number" min="0" class="box" name="product_price" value="<?php echo $row['price']; ?>" placeholder="ادخل سعر المنتج">
	  <input type="number" min="0" class="box" name="product_quan" value="<?php echo $row['quantity']; ?>" placeholder="ادخل كمية المنتج">
	  <input type="text" min="0" class="box" name="product_des" value="<?php echo $row['desc']; ?>" placeholder="ادخل وصف المنتج">
      <input type="file" class="box" name="product_image"  accept="image/png, image/jpeg, image/jpg">
      <input type="submit" value="تحديث معلومات المنتج" name="update_product" class="btn">
      <a href="adminPage.php" class="btn">الرجوع للخلف</a>
   </form>
   


   <?php }; ?>

   

</div>

</div>


		 <!---footer--->
    <div class="footer">
    <div class="container">
        <div class="row">

            <div class="footer-col-4">
            <h3 id="contact"> للتواصل </h3>
            <ul>
            <li>ِ<a href="mailto:Shirostudio21@gmail.com"><i style="font-size:24px" class="fa">&#xf003;</i>  Email</a></li>
            <li><a href="https://api.whatsapp.com/send/?phone=966591110744&text&type=phone_number&app_absent=0"><i style="font-size:24px" class="fa">&#xf232;</i>  Whatsapp </a></li>
            </ul>
            </div>
            
            <div class="footer-col-2">
            <img src="https://media.zid.store/cdn-cgi/image/h=175,q=85/https://media.zid.store/dddf4b16-a4fa-4b62-add8-3b090ade4cb1/f15d6435-3536-4475-a2ac-bdb20e61e259.jpg">
            <p>هدفنا هو حصولكم على أجود المنتجات المصنوعة خصيصًا لكم</p>
            </div>
            
            <div class="footer-col-3">
            <h3>حساباتنا</h3>
                <ul>
                <li><a href="https://www.tiktok.com/@shiro_studio">TikTok</a> </li>
                <li><a href="https://www.instagram.com/shirostudio1/"><i style="font-size:24px" class="fa">&#xf16d;</i>  Instagram </a></li>
                <li><a href="https://www.snapchat.com/add/shiro_studio21"><i style="font-size:24px" class="fa">&#xf2ab;</i>     Snapchat</a> </li>
                </ul>
            </div>
        </div>
        
           <hr>
            <p class="copyright">Copyright 2023 - Group 6</p>
        </div>
    </div>
	 <!---js for product gallery--->
    <script>
    var productImg = document.getElementById("productImg");
    var smallImg = document.getElementsByClassName("smallImg"); 
    smallImg[0].onclick = function()
    {
        productImg.src= smallImg[0].src;
    }
    smallImg[1].onclick = function()
    {
        productImg.src= smallImg[1].src;
    }
    smallImg[2].onclick = function()
    {
        productImg.src= smallImg[2].src;
    }
    smallImg[3].onclick = function()
    {
        productImg.src= smallImg[3].src;
    } 
    </script>
	
	
</body>
</html>