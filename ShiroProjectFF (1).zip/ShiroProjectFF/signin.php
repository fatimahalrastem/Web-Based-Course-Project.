<?php
include("connection.php");

if(isset($_POST ['submit'])) {

    $f_name =$_POST['firstName'] ?? '';
    $l_name =$_POST['lastName'] ?? '';
    $username =$_POST['username'] ?? '';
    $email =$_POST['email'] ?? '';
    $password =$_POST['password'] ?? '';


    $s = "select * from signin where username='$username' ";
    $result = mysqli_query($conn, $s);

    if (!$result) {
        $count = 0;
    } else {
        $count = mysqli_num_rows ($result);
    }
    	
if(empty($_POST['firstName'])){
	echo '<script>
		   window.location.href ="index2.php";
		   alert("الرجاء تعبئة حقل الاسم الاول")
		   </script>';
}
if(empty($_POST['lastName'])) {
	echo '<script>
		   window.location.href ="index2.php";
		   alert("الرجاء تعبئة حقل الاسم الاخير")
		   </script>';
}


if(empty($_POST['username'])){
	echo '<script>
		   window.location.href ="index2.php";
		   alert("الرجاء تعبئة حقل الاسم المستخدم")
		   </script>';
}

if(empty($_POST['email'])) {
	echo '<script>
		   window.location.href ="index2.php";
		   alert("الرجاء تعبئة حقل البريد الالكتروني")
		   </script>';
}

if(empty($_POST['password'])){
	echo '<script>
		   window.location.href ="index2.php";
		   alert("الرجاء تعبئة حقل الرمز السري")
		   </script>';
}
else{
	$uppercase    = preg_match('@[A-Z]@', $password);
    $lowercase    = preg_match('@[a-z]@', $password);
    $number       = preg_match('@[0-9]@', $password);
    $specialchars = preg_match('@[^\w]@', $password);
  
  if (!$uppercase || !$lowercase || !$number || !$specialchars || strlen($password) < 8) {
  
	echo '<script>
		   window.location.href ="index2.php";
		   alert("الرمز السري ضعيف")
		   </script>';
    
  } 

}
	 if($count === 1){
		 
		 echo '<script>
		   window.location.href ="index2.php";
		   alert("اسم المستخدم مسخدم سابقًا ")
		   </script>';
	 }
	 else {
         
		 $reg="insert into signin (f_name , l_name , username ,email ,password) 
		 values ('$f_name' ,'$l_name' ,'$username' ,'$email' ,'$password')";
		
         $conn->init();
        
         if ($conn->query($reg) === true) {
		 echo '<script>
		   window.location.href ="index2.php";
		   alert("تم التسجيل بنجاح! قم بتسجيل الدخول الان")
		   </script>';
         } else {
             echo "Error: " . $reg . "<br>" . $conn->error;
         }
	 }
}
?>