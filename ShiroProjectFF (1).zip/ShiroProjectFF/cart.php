<?php 
	error_reporting(0);
	include('connection.php');
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>المنتجات</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@200;300;400;500;600&family=Noto+Kufi+Arabic:wght@300;400;500;600;700&family=Noto+Sans+Arabic:wght@200;300;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="shirostyle.css" rel="stylesheet" type="text/css"> 
<style> 
*{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    } 
    body{
        font-family: 'IBM Plex Sans Arabic', sans-serif;
        font-family: 'Noto Kufi Arabic', sans-serif;
        font-family: 'Noto Sans Arabic', sans-serif;
    }
    .navbar{
        display: flex;
        align-items: center;
        padding: 20px;
         background: #000000;
    }
    nav{
        flex: 1;
        text-align: right;
    }
    nav ul{
        display: inline-block;
        list-style-type: none;
    }
    nav ul li{
        display: inline-block;
        margin-right: 20px;
    }
    a{
        text-decoration: none;
        color: #fff;
    }
    p{
        color: #000000;
    }
    .container{
        max-width: 1300px;
        margin: auto;
        padding-left: 25px;
        padding-right: 25px;
    }
    .row{
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        justify-content: space-around;
    }
    .col-2{
        flex-basis: 50%;
        min-width: 300px;
    }
    .col-2 img{
        max-width: 100%;
        padding: 50px 0;
    }
    .col-2 h1{
        font-size: 50px;
        line-height: 60px;
        margin: 25px 0;
    }
    .col-2 p{
        color: #000000;
    }
    .btn{
        display: inline-block;
        background: #000000;
        color: white;
        padding: 8px 30px;
        margin: 30px 0;
        border-radius: 30px;
        transition: background 0.5s;
    }
    span {
  content: "\2192";
    }
    .btn:hover{
        background: #808080;
    }
    .header{
        background: radial-gradient(#fff,#000000);
    }
    .header row{
       margin-top: 70px; 
    }
    .categories{
      margin: 70px 0;  
    }
    .col-3{
        flex-basis: 30%;
        min-width: 250px;
        margin-bottom: 30px;
    }
    .col-3 img{
        width: 100%;
    }
    .small-container{
        max-width: 1080px;
        margin: auto;
        padding-left: 25px;
        padding-right: 25px;
    }
    .col-4{
        flex-basis: 25%;
        padding: 10px;
        min-width: 200px;
        margin-bottom: 50px;
        transition: transform 0.5s;
    }
    .col-4 img{
        width: 100%;
    }
    .rating{
    text-align: right;
    }
    .rating .fa{
    color: gold;
    } 
    .title{
        text-align: center;
        margin: 0 auto 80px;
        position: relative;
        line-height: 60px;
        color: #555;
    }
    .title:after{
        content: '';
        background: #000000;
        width: 80px;
        height: 5px;
        border-radius: 5px;
        position: absolute;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
    }
    h4{
        color: #000000;
        font-weight: normal;
    }
    .col-4 p{
        font-size: 14px;
        text-align: right;
    }
    .col-4:hover{
        transform: translateY(-5px);
    }
    .col-4 h4{
        text-align: right;
    }
    .col-7{
        flex-basis: 25%;
        padding: 10px;
        min-width: 200px;
        margin-bottom: 50px;
        transition: transform 0.5s;  
    }
    .col-7 img{
       width: 100%; 
    }
    .col-7 p{
        font-size: 14px;
    }
    .col-7:hover{
        transform: translateY(-5px);
    }
    .col-7 h4{
        text-align: right;
    }
    .offer{
        background: radial-gradient(#fff,#000000);
        margin-top: 80px;
        padding: 30px; 
    }
    .col-2 .offer-img{
        padding: 50px;
    }
    small{
        color: #555;
        
    }
    
    /*---testimonial---*/
    .testimonial{
        padding-top: 100px;
    }
    .testimonial .col-3{
        text-align: center;
        padding: 40px 20px;
        box-shadow: 0 0 20px 0px rgba(0,0,0,0.1);
        cursor:pointer;
        transition: transform 0.5s;
    }
    .testimonial .col-3 img{
        width: 50px;
        margin-top: 20px;
        border-radius: 50%;
    }
    .testimonial .rating{
        text-align: center;
    }
    .testimonial .col-3:hover{
        transform: translateY(-10px);
    }
    .fa.fa-quote-left{
        font-size: 34px;
        color: #000000;
    }
    .col-3 p{
        font-size: 12px;
        margin: 12px 0;
        color: #777;
    }
    .testimonial .col-3 h3{
        font-weight: 600;
        color: #555;
        font-size: 16px;
    }
    
    /*---icons---*/
    .icons{
        margin: 100px auto;
    }
    .col-5{
        width: 160px;
    }
    .col-5 img{
        width: 100%;
        cursor: pointer;
    }
   
    /*---footer---*/
    .footer{
        background: #000000;
        color: #8a8a8a;
        font-size: 14px;
        padding: 60px 0 20px;
    }
    .footer p{
        color: #8a8a8a;
    }
    .footer h3{
        color: #fff;
        margin-bottom: 20px; 
    }
    .footer-col-1, footer-col-2, footer-col-3, footer-col-4{
        min-width: 250px;
        margin-bottom: 20px;
    }
    .footer-col-1{
        flex-basis: 30%;
    }
    .footer-col-2{
        flex: 1;
        text-align: center;
    }
    .footer-col-2 img{
        width: 180px;
        margin-bottom: 20px;
    }
    footer-col-3, .footer-col-4{
        flex-basis: 12%;
        text-align: center;
    }
    ul{
        list-style-type: none;
    }
    .footer hr{
        border: none;
        background: #b5b5b5;
        height: 1px;
        margin: 20px 0;
    }
    .copyright{
        text-align: center;
    }
    
    /*---single-products---*/
    .single-products{
        margin-top: 80px;
    }
    .single-products .col-2 img{
        padding: 0;
        
    }
    .single-products .col-2{
        padding: 20px;
        
    }
    .single-products h4{
        margin: 20px 0;
        font-size:  22px;
        font-weight: bold;
    }
    .single-products select{
        display: block;
        padding: 10px;
        margin-top: 20px;
    }
    .single-products input{
        width: 50px;
        height: 40px;
        padding-left: 10px;
        font-size: 20px;
        margin-right: 10px;
        border: 1px solid #000000 ;
    }
    input:focus{
        outline: none;
    }
    .single-product .fa{
        color: #000000;
        margin-left: 10px;
    }
    .small-img-row{
        display: flex;
        justify-content: space-between;
    }
    .small-img-col{
        flex-basis: 24%;
        cursor: pointer;
    }
	.content-wrapper {
	width: 1050px;
	margin: 0 auto;
}
 .cart h1 {
	display: block;
	font-weight: normal;
	margin: 0;
	padding: 40px 0;
	font-size: 24px;
	text-align: center;
	width: 100%;
}
 .cart table {
	width: 100%;
}
 .cart table thead td {
	padding: 30px 0;
	border-bottom: 1px solid #EEEEEE;
}
 .cart table thead td:last-child {
	text-align: right;
}
 .cart table tbody td {
	padding: 20px 0;
	border-bottom: 1px solid #EEEEEE;
}
 .cart table tbody td:last-child {
	text-align: right;
}
 .cart table .img {
	width: 80px;
}
 .cart table .remove {
	color: #777777;
	font-size: 12px;
	padding-top: 3px;
}
 .cart table .remove:hover {
	text-decoration: underline;
}
 .cart table .price {
	color: #999999;
}
 .cart table a {
	text-decoration: none;
	color: #555555;
}
 .cart table input[type="number"] {
	width: 68px;
	padding: 10px;
	border: 1px solid #ccc;
	color: #555555;
	border-radius: 5px;
}
 .cart .subtotal {
	text-align: right;
	padding: 40px 0;
}
 .cart .subtotal .text {
	padding-right: 40px;
	font-size: 18px;
}
 .cart .subtotal .price {
	font-size: 18px;
	color: #999999;
}
 .cart .buttons {
	text-align: right;
	padding-bottom: 40px;
}
 .cart .buttons input[type="submit"] {
	margin-left: 5px;
	padding: 12px 20px;
	border: 0;
	background: #4e5c70;
	color: #FFFFFF;
	font-size: 14px;
	font-weight: bold;
	cursor: pointer;
	border-radius: 5px;
}
 .cart .buttons input[type="submit"]:hover {
	background: #434f61;
}
 .placeorder h1 {
	display: block;
	font-weight: normal;
	margin: 0;
	padding: 40px 0;
	font-size: 24px;
	text-align: center;
	width: 100%;
}
 .placeorder p {
	text-align: center;
}
</style>
</head>
<?php
if (isset($_GET['product_id'], $_GET['quantity']) && is_numeric($_GET['product_id']) && is_numeric($_GET['quantity'])) {

    $product_id = (int)$_GET['product_id'];
    $quantity = (int)$_GET['quantity'];
    $stmt = $pdo->prepare('SELECT * FROM products WHERE id = ?');
    $stmt->execute([$product_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($product && $quantity > 0) {
        if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
            if (array_key_exists($product_id, $_SESSION['cart'])) {
                $_SESSION['cart'][$product_id] += $quantity;
            } else {
                $_SESSION['cart'][$product_id] = $quantity;
            }
        } else {
            $_SESSION['cart'] = array($product_id => $quantity);
        }
    }
   
}
if (isset($_GET['remove']) && is_numeric($_GET['remove']) && isset($_SESSION['cart']) && isset($_SESSION['cart'][$_GET['remove']])) {
    unset($_SESSION['cart'][$_GET['remove']]);
}
if (isset($_POST['update']) && isset($_SESSION['cart'])) {
    foreach ($_POST as $k => $v) {
        if (strpos($k, 'quantity') !== false && is_numeric($v)) {
            $id = str_replace('quantity-', '', $k);
            $quantity = (int)$v;
            if (is_numeric($id) && isset($_SESSION['cart'][$id]) && $quantity > 0) {
                $_SESSION['cart'][$id] = $quantity;
            }
        }
    }
 
}
if (isset($_POST['placeorder']) && isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
  
   $username = $_SESSION["username"];
	$sql = "INSERT INTO orders (user_name)
			VALUES ('".$username."');";
			
	// echo $sql;
	// die;
			
	//mysqli_set_charset($conn,"utf8");			
	mysqli_query($conn, $sql);		
	$order_id = mysqli_insert_id($conn);
	
	 // echo $order_id;
	 // die;

	foreach($_SESSION['cart'] as $product_id => $qty){
			//$name = getProductNameById($product_id);				
			//$price = getProductPriceById($product_id);			
			//$total_price = $price * $qty;
			$sql = "INSERT INTO order_items (order_id, product_id, qty)
			VALUES (  ".$order_id."  , '".$product_id."' , '".$qty."' );";
			//mysqli_set_charset($conn,"utf8");						
			 // echo $sql;
			 // die;			
			mysqli_query($conn, $sql);		
	}		
	session_destroy();
	echo "<script>window.location.href='placeorder.php';</script>";
	exit;

}
$products_in_cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : array();
$products = array();
$subtotal = 0.00;
if ($products_in_cart) {

    $array_to_question_marks = implode(',', array_fill(0, count($products_in_cart), '?'));
    $stmt = $pdo->prepare('SELECT * FROM products WHERE id IN (' . $array_to_question_marks . ')');
    $stmt->execute(array_keys($products_in_cart));
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($products as $product) {
        $subtotal += (float)$product['price'] * (int)$products_in_cart[$product['id']];
    }
}



function getProductNameById($id){
	$conn = mysqli_connect('localhost','root','','shiro');	
	$sql = "SELECT name FROM products where id = ".$id;
	mysqli_set_charset($conn,"utf8");
	$result = mysqli_query($conn, $sql);
	while($row = mysqli_fetch_assoc($result)) {
		$result = $row["name"];
	}	
	return $result;	
}

function getProductPriceById($id){
	$conn = mysqli_connect('localhost','root','','shiro');
	$sql = "SELECT price FROM products where id = ".$id;
	$result = mysqli_query($conn, $sql);
	while($row = mysqli_fetch_assoc($result)) {
		header('Content-Type: text/html; charset=utf-8');
		$result = $row["price"];
	}	
	return $result;	
}





?>
   
<body>
     <!---header--->

<div class="navbar">
    <div class="logo">
        <img src="https://media.zid.store/cdn-cgi/image/h=175,q=85/https://media.zid.store/dddf4b16-a4fa-4b62-add8-3b090ade4cb1/f15d6435-3536-4475-a2ac-bdb20e61e259.jpg" width="125px">
    </div>
    <nav>
    <ul>
	<?php
	
	if (! empty($_SESSION["username"])) {
		echo '<li><a href="javascript:0">'.ucfirst($_SESSION["username"]).'</a></li>|<a href="logout.php">Logout</a></li><li>'; 
	} 
	
	?>	
    <li><a href="index2.php">حسابي</a></li> 
    <li> <a href = "#contact">للتواصل</a></li>
    <li><a href="story.html">قصتنا</a></li>
    <li><a href="index.php?page=products">المنتجات</a></li>
    <li><a href="index.php">الصفحة الرئيسية</a></li> 
    </ul>
    </nav>

    <div class="link-icons">
                    <a href="index.php?page=cart">
						<i class="fa fa-shopping-cart"></i>
					</a>
                </div>
    </div>
  
    <br>

	<div class="cart content-wrapper">
    <h1>سلة المشتريات</h1>
    <form action="cart.php" method="post">
        <table>
            <thead>
                <tr>
                    <td colspan="2">المنتجات</td>
                    <td>السعر</td>
                    <td>الكمية</td>
                    <td>المجموع</td>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($products)): ?>
                <tr>
                    <td colspan="5" style="text-align:center;">! لا يوجد لديك منتجات في السلة</td>
                </tr>
                <?php else: ?>
                <?php foreach ($products as $product): ?>
                <tr>
                    <td class="img">
                        <a href="index.php?page=product&id=<?=$product['id']?>">
                            <img src="<?=$product['img']?>" width="50" height="50" alt="<?=$product['name']?>">
                        </a>
                    </td>
                    <td>
                        <a href="index.php?page=product&id=<?=$product['id']?>"><?=$product['name']?></a>
                        <br>
                        <a href="index.php?page=cart&remove=<?=$product['id']?>" class="remove">حذف</a>
                    </td>
                    <td class="price">&#65020;<?=$product['price']?></td>
                    <td class="quantity">
                        <input type="number" name="quantity-<?=$product['id']?>" value="<?=$products_in_cart[$product['id']]?>" min="1" max="<?=$product['quantity']?>" placeholder="Quantity" required>
                    </td>
                    <td class="price">&#65020;<?=$product['price'] * $products_in_cart[$product['id']]?></td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
        <div class="subtotal">
            <span class="text">المجموع النهائي  </span>
            <span class="price">&#65020;<?=$subtotal?></span>
        </div>
        <div class="buttons">
            <input type="submit" value="تحديث" name="update">
            <input type="submit" value="انهاء الطلب" name="placeorder">
        </div>
    </form>
</div>

   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
    
        <!---footer--->
    <div class="footer">
    <div class="container">
        <div class="row">

            <div class="footer-col-4">
            <h3 id="contact">للتواصل</h3>
            <ul>
            <li>ِ<a href="mailto:Shirostudio21@gmail.com"><i style="font-size:24px" class="fa">&#xf003;</i>  Email</a></li>
            <li><a href="https://api.whatsapp.com/send/?phone=966591110744&text&type=phone_number&app_absent=0"><i style="font-size:24px" class="fa">&#xf232;</i>  Whatsapp </a></li>
            </ul>
            </div>
            
            <div class="footer-col-2">
            <img src="https://media.zid.store/cdn-cgi/image/h=175,q=85/https://media.zid.store/dddf4b16-a4fa-4b62-add8-3b090ade4cb1/f15d6435-3536-4475-a2ac-bdb20e61e259.jpg">
            <p>هدفنا هو حصولكم على أجود المنتجات المصنوعة خصيصًا لكم</p>
            </div>
            
            <div class="footer-col-3">
            <h3>حساباتنا</h3>
                <ul>
                <li><a href="https://www.tiktok.com/@shiro_studio">TikTok</a> </li>
                <li><a href="https://www.instagram.com/shirostudio1/"><i style="font-size:24px" class="fa">&#xf16d;</i>  Instagram </a></li>
                <li><a href="https://www.snapchat.com/add/shiro_studio21"><i style="font-size:24px" class="fa">&#xf2ab;</i>     Snapchat</a> </li>
                </ul>
            </div>
        </div>
        
           <hr>
            <p class="copyright">Copyright 2023 - Group 6</p>
        </div>
    </div>
    
   
</body>
</html>
