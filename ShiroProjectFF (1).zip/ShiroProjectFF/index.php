<?php
session_start();

include 'connection.php';

$page = isset($_GET['page']) && file_exists($_GET['page'] . '.php') ? $_GET['page'] : 'homePage';

include $page . '.php';
?>