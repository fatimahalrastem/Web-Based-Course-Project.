<DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>المنتجات</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@200;300;400;500;600&family=Noto+Kufi+Arabic:wght@300;400;500;600;700&family=Noto+Sans+Arabic:wght@200;300;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="shirostyle.css" rel="stylesheet" type="text/css"> 
<style>
    *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    } 
    body{
        font-family: 'IBM Plex Sans Arabic', sans-serif;
        font-family: 'Noto Kufi Arabic', sans-serif;
        font-family: 'Noto Sans Arabic', sans-serif;
    }
    .navbar{
        display: flex;
        align-items: center;
        padding: 20px;
         background: #000000;
    }
    nav{
        flex: 1;
        text-align: right;
    }
    nav ul{
        display: inline-block;
        list-style-type: none;
    }
    nav ul li{
        display: inline-block;
        margin-right: 20px;
    }
    a{
        text-decoration: none;
        color: #fff;
    }
    p{
        color: #000000;
    }
    .container{
        max-width: 1300px;
        margin: auto;
        padding-left: 25px;
        padding-right: 25px;
    }
    .row{
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        justify-content: space-around;
    }
    .categories{
      margin: 70px 0;  
    }
    .col-3{
        flex-basis: 30%;
        min-width: 250px;
        margin-bottom: 30px;
    }
    .col-3 img{
        width: 100%;
    }
    .small-container{
        max-width: 1080px;
        margin: auto;
        padding-left: 25px;
        padding-right: 25px;
    }
    .col-4{
        flex-basis: 25%;
        padding: 10px;
        min-width: 200px;
        margin-bottom: 50px;
        transition: transform 0.5s;
    }
    .col-4 img{
        width: 100%;
    }
    .rating{
    text-align: right;
    }
    .rating .fa{
    color: gold;
    } 
    .title{
        text-align: center;
        margin: 0 auto 80px;
        position: relative;
        line-height: 60px;
        color: #555;
    }
    .title:after{
        content: '';
        background: #000000;
        width: 80px;
        height: 5px;
        border-radius: 5px;
        position: absolute;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
    }
    h4{
        color: #000000;
        font-weight: normal;
    }
    .col-4 p{
        font-size: 14px;
        text-align: right;
    }
    .col-4:hover{
        transform: translateY(-5px);
    }
    .col-4 h4{
        text-align: right;
    }

/*---footer---*/
    .footer{
        background: #000000;
        color: #8a8a8a;
        font-size: 14px;
        padding: 60px 0 20px;
    }
    .footer p{
        color: #8a8a8a;
    }
    .footer h3{
        color: #fff;
        margin-bottom: 20px; 
    }
    .footer-col-1, footer-col-2, footer-col-3, footer-col-4{
        min-width: 250px;
        margin-bottom: 20px;
    }
    .footer-col-1{
        flex-basis: 30%;
    }
    .footer-col-2{
        flex: 1;
        text-align: center;
    }
    .footer-col-2 img{
        width: 180px;
        margin-bottom: 20px;
    }
    footer-col-3, .footer-col-4{
        flex-basis: 12%;
        text-align: center;
    }
    ul{
        list-style-type: none;
    }
    .footer hr{
        border: none;
        background: #b5b5b5;
        height: 1px;
        margin: 20px 0;
    }
    .copyright{
        text-align: center;
    }
	.dropbtn {
  background-color: #f5f5f5;
  color: black;
  padding: 4px;
  font-size: 17px;
  border: none;
  position: absolute;
  right:0;
   border-radius:25px;
 
}

.dropdown {
  position:right;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  right:5em;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: #ddd;}

/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {display: block;}

/* Change the background color of the dropdown button when the dropdown content is shown */
.dropdown:hover .dropbtn {background-color: #fff;}
    .container{
        max-width: 1500px;
        margin: auto;
        padding-left: 25px;
        padding-right: 25px;
    }
</style>
</head>
    
<body>

<div class="navbar">
    <div class="logo">
        <img src="https://media.zid.store/cdn-cgi/image/h=175,q=85/https://media.zid.store/dddf4b16-a4fa-4b62-add8-3b090ade4cb1/f15d6435-3536-4475-a2ac-bdb20e61e259.jpg" width="125px">
    </div>
    <nav>
    <ul>
	<?php
	
	if (! empty($_SESSION["username"])) {
		echo '<li><a href="javascript:0">'.ucfirst($_SESSION["username"]).'</a></li>|<a href="logout.php">Logout</a></li><li>'; 
	} 
	
	?>	
    <li><a href="index2.php">حسابي</a></li> 
    <li> <a href = "#contact">للتواصل</a></li>
    <li><a href="story.html">قصتنا</a></li>
    <li><a href="index.php?page=products">المنتجات</a></li>
    <li><a href="index.php">الصفحة الرئيسية</a></li> 
    </ul>
    </nav>

    <div class="link-icons">
                    <a href="index.php?page=cart">
						<i class="fa fa-shopping-cart"></i>
					</a>
                </div>
    </div>

    <br>

<?php
$current_page = isset($_GET['p']) && is_numeric($_GET['p']) ? (int)$_GET['p'] : 1;
$stmt = $pdo->prepare('SELECT * FROM products');
$stmt->execute(); 
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
	
	<!--  المنتجات -->    
    <!--  معطرات المنزل --> 
 <div class="small-container">
        <h2 class="title">المنتجات</h2>
        <br>
       
        <div class="row">
		<?php foreach ($products as $product): ?>
        <div class="col-4">
		
		  <a href="index.php?page=product&id=<?=$product['id']?>" class="product">
		   <img src="<?=$product['img']?>" alt="<?=$product['name']?>">
            <h4><?=$product['name']?></h4>
            
            <div class="rating">
            <i class="fa fa-star" ></i>
            <i class="fa fa-star"></i>
            <i class="fa fa-star"></i>
            <i class="fa fa-star"></i>
            <i class="fa fa-star-half-o"></i>
            </div>
            <p><?=$product['price']?> رس</p>
			 </a>
			
            </div>
             <?php endforeach; ?>
            </div>	
		</div>
	
	
        <!---footer--->
    <div class="footer">
    <div class="container">
        <div class="row">

            <div class="footer-col-4">
            <h3 id="contact"> للتواصل </h3>
            <ul>
            <li>ِ<a href="mailto:Shirostudio21@gmail.com"><i style="font-size:24px" class="fa">&#xf003;</i>  Email</a></li>
            <li><a href="https://api.whatsapp.com/send/?phone=966591110744&text&type=phone_number&app_absent=0"><i style="font-size:24px" class="fa">&#xf232;</i>  Whatsapp </a></li>
            </ul>
            </div>
            
            <div class="footer-col-2">
            <img src="https://media.zid.store/cdn-cgi/image/h=175,q=85/https://media.zid.store/dddf4b16-a4fa-4b62-add8-3b090ade4cb1/f15d6435-3536-4475-a2ac-bdb20e61e259.jpg">
            <p>هدفنا هو حصولكم على أجود المنتجات المصنوعة خصيصًا لكم</p>
            </div>
            
            <div class="footer-col-3">
            <h3>حساباتنا</h3>
                <ul>
                <li><a href="https://www.tiktok.com/@shiro_studio">TikTok</a> </li>
                <li><a href="https://www.instagram.com/shirostudio1/"><i style="font-size:24px" class="fa">&#xf16d;</i>  Instagram </a></li>
                <li><a href="https://www.snapchat.com/add/shiro_studio21"><i style="font-size:24px" class="fa">&#xf2ab;</i>     Snapchat</a> </li>
                </ul>
            </div>
        </div>
        
           <hr>
            <p class="copyright">Copyright 2023 - Group 6</p>
        </div>
    </div>
          
</body>
</html>