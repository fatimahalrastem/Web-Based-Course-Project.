-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 12, 2023 at 04:48 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shiro`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminlogin`
--

CREATE TABLE `adminlogin` (
  `Username` varchar(30) NOT NULL,
  `Password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adminlogin`
--

INSERT INTO `adminlogin` (`Username`, `Password`) VALUES
('admin', '123123');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_name` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_name`) VALUES
(1, 'ali'),
(2, 'ali');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `qty`) VALUES
(1, 1, 2, 3),
(2, 1, 26, 5),
(3, 2, 26, 2),
(4, 2, 3, 3),
(5, 2, 1, 4);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `desc` text NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `img` text NOT NULL,
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `desc`, `price`, `img`, `date_added`, `quantity`) VALUES
(2, 'O2 معطر منزلي', '', '59', 'img/2.jpg', '2023-02-04 13:41:22', 5),
(3, 'زيت عطري برائحة المطر', '', '29', 'img/3.jpeg', '2023-02-04 13:42:27', 20),
(4, 'زيت عطري برائحة العنبر والفانيليا', '', '29', 'img/4.jpeg', '2023-02-04 13:43:57', 20),
(5, 'زيت عطري برائحة الفل الفرنسي', '', '29', 'img/5.jpeg', '2023-02-04 13:44:48', 25),
(6, 'مكعبات فواحة برائحة الكرز الياباني', '', '60', 'img/6.jpg', '2023-02-04 13:45:48', 20),
(7, 'مكعبات فواحة برائحة اللافندر', '', '35', 'img/7.jpg', '2023-02-04 13:46:40', 25),
(8, 'طفايات شموع', '', '29', 'img/8.jpg', '2023-02-04 13:49:33', 50),
(9, 'شمعدان فخار باللون الأبيض', '', '99', 'img/9.jpg', '2023-02-04 13:51:02', 30),
(10, 'شمعدان ذهبي', '', '99', 'img/10.jpg', '2023-02-04 13:52:10', 25),
(11, 'ملصقات', '', '9', 'img/11.png', '2023-02-04 13:53:27', 50),
(12, 'ملصقات', '', '9', 'img/12.png', '2023-02-04 13:54:24', 50),
(13, 'شمعة عطرية برائحة الياسمين', '', '35', 'img/13.jpeg', '2023-02-04 13:59:34', 20),
(14, 'شمعة عطرية برائحة التوت البري', '', '35', 'img/14.jpg', '2023-02-04 14:03:02', 20),
(15, 'شمعة عطرية برائحة الفل الفرنسي', '', '35', 'img/15.jpeg', '2023-02-04 14:04:02', 20),
(16, 'شمعة عطرية برائحة زهرة الافونيا', '', '259', 'img/16.jpg', '2023-02-04 14:05:05', 18),
(17, 'شمعة عطرية برائحة المحيط', '', '349', 'img/17.jpg', '2023-02-04 14:06:07', 18),
(18, 'شمعة خشب برائحة الافندر', '', '129', 'img/18.jpg', '2023-02-04 14:07:13', 20),
(19, 'شمعة الكاميليا', '', '15', 'img/19.jpg', '2023-02-04 14:10:11', 30),
(20, 'شمعة سول', '', '56', 'img/20.jpg', '2023-02-04 14:10:58', 30),
(21, 'قاعده بخور باللون الاسود', '', '99', 'img/21.jpeg', '2023-02-04 14:11:56', 25),
(22, 'سجاد', '', '1599', 'img/22.jpg', '2023-02-04 14:13:21', 4),
(23, 'سجاد مرسوم', '', '899', 'img/23.jpg', '2023-02-04 14:14:24', 4),
(24, 'كوستر', '', '39', 'img/24.jpg', '2023-02-04 14:15:36', 20),
(25, 'بساط زهري', '', '119', 'img/25.jpg', '2023-02-04 14:16:33', 20),
(26, 'بساط اخضر رمادي', '', '119', 'img/26.jpg', '2023-02-04 14:17:25', 20),
(27, 'كوستر', '', '39', 'img/27.jpg', '2023-02-04 14:18:30', 20),
(28, 'شمعة', 'شمعه', '55', 'img/candel 2.jpeg', '2023-02-12 14:43:50', 2);

-- --------------------------------------------------------

--
-- Table structure for table `signin`
--

CREATE TABLE `signin` (
  `f_name` varchar(30) NOT NULL,
  `l_name` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `signin`
--

INSERT INTO `signin` (`f_name`, `l_name`, `username`, `email`, `password`) VALUES
('Bushra', 'Alshehri', 'bushra13', 'bushraalshehri14@gmail.com', 'Ba@00000'),
('Bushra', 'Alshehri', 'bushra855', 'bushraalshehri15@gmail.com', 'Bm@00000'),
('mohammed', 'alshehri', 'bushra12', 'Mo0omd9111@gmail.com', 'bm11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminlogin`
--
ALTER TABLE `adminlogin`
  ADD PRIMARY KEY (`Username`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signin`
--
ALTER TABLE `signin`
  ADD PRIMARY KEY (`email`),
  ADD KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
