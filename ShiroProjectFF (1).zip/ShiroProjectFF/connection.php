<?php


$servername = "localhost";
    $username = "root";
    $password = "";
    $db_name = "shiro";
    $conn = new mysqli($servername, $username, $password, $db_name);

    if($conn->connect_error){
        die("Connection failed".$conn->connect_error);
    }

function pdo_connect_mysql() {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $db_name = "shiro";
    try {
        return new PDO('mysql:host=' . $servername . ';dbname=' . $db_name . ';charset=utf8', $username, $password);
    } catch (PDOException $exception) {
        // If there is an error with the connection, stop the script and display the error.
        exit('Failed to connect to database!');
    }
}
$pdo = pdo_connect_mysql();

?>


